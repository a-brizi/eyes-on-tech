package com.adevinta

package object utils  {
  
   import java.io.File
   import scala.io.Source

   def getListOfFiles(dir: String):List[File] = {
  
       val d = new File(dir)
       if (d.exists && d.isDirectory) {
           d.listFiles.filter(_.isFile).toList
       } else {
           List[File]()
       }
   }
   
   def myContains(inputData: Map[String,Map[String,Int]], funct: Seq[String]):Iterable[(String,Int)] = {
    
      inputData.map(pair => (pair._1, pair._2.keys.toList.map(word => (funct collect {case str if word equals str => 1}).fold(0)(_+_)).reduce(_+_)))

   }
   
   def Search(dir: String): Unit = {
      val listOfFiles = getListOfFiles(dir)
      if (listOfFiles.length != 0) println(listOfFiles.length + " files read in directory " + dir) 
         else { println("wrong directory name: directory is empty...") ; System.exit(1) }
      val input = listOfFiles.map(file => (file.getName,Source.fromFile(file).getLines.mkString("\n").split("[\n& ]"))).toMap
      val countedInput = input.map(pair => (pair._1, pair._2.map(word => (word,1)).groupBy(_._1).mapValues(seq => seq.map(_._2).reduce(_+_)).toMap))
      var toBeSearched = scala.io.StdIn.readLine("search> ").split(" ")
      while (toBeSearched.size != 1 || toBeSearched(0) != ":quit") {
         val toBeSearchedLength = toBeSearched.size
         val output = myContains(countedInput,toBeSearched).filterNot(_._2 == 0)
         if (output.size == 0) print("no matches found\n") else {output.foreach(pair => println(pair._1 + " : " + (pair._2.toFloat/toBeSearchedLength)*100 + " %"))}
         toBeSearched = scala.io.StdIn.readLine("search> ").split(" ")
      }
      println("Now exit Searcher ...")
   }
}