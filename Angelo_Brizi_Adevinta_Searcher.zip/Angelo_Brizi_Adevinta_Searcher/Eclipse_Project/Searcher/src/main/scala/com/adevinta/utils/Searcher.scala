package com.adevinta.utils

object Searcher extends App {
  
   if (args.length != 1) {
      throw new RuntimeException(s"Wrong arguments number: supplied ${args.length} - requested: 1 (absolute path to the directory to search for files ...)")
   }
   
   val dir = args(0)
   
   Search(dir)
  
}