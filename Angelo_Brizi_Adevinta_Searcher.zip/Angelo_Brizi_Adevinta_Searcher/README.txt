/************************************************************************************************************************
*                                                                                                                       *
*                                                README                                                                 *
*                                                                                                                       *
************************************************************************************************************************/

TIME USED TO BUILD CODE (scala code + linux shell): approx 2 hours

PACKAGE CONTENTS (zip file):

Files:           textual files for test

jar:             jar file to execute

utility:         file builder for test files (adevinta_file_builder.sh + usage.txt)

Eclipse_Project: The complete Eclipse Project

README:          this file

---------------------------------------------------------------------------

How to lunch:

java -jar searcher_2.11-1.0.jar com.adevinta.utils.Searcher /path/to/Files

---------------------------------------------------------------------------

ASSUMPTIONS:

1) - The code was developed using Scala 2.11.11

2) - I used Eclipse Version: 2019-06 (4.12.0) Build id: 20190614-1200

3) - It was tested in "quick and dirty" mode in Eclipse environment and it runs with no erro

4) - I wrote a shell script "adevinta_file_builder.sh" just to produce some very silly test file (you can modify the script
     at your own to build more interesting contents)

------------------------------------------------------------------------------------------------------------------------

0) What do we mean by the term "word"?
According to the example indicated in the exercise text, 
I would like to assume that a "word" is a sequence of characters separated from the next "word" by one or more spaces.

Example of words:
to
well
or
not
to
well
"to be or not to be"

Example:

to be or not to be ---> Map(word1 -> "to", word2 -> "be", word3 -> "or", word4 -> "not", word5 -> "to", word6 -> "be")

"to be or not to be" ---> Map(word1 -> "to be or not to be")
*/

------------------------------------------------------------------------------------------------------------------------

************************************************************************************************************************
*                                                                                                                      *
*                                               Software Components                                                    *
*                                                                                                                      *
************************************************************************************************************************


1) DIRECTORY LISTING:

import java.io.File
import scala.io.Source

def getListOfFiles(dir: String):List[File] = {
    val d = new File(dir)
    if (d.exists && d.isDirectory) {
        d.listFiles.filter(_.isFile).toList
    } else {
        List[File]()
    }
}

----------------------------------------------------------------------------------------------------------------------------

2) FILES CONTENTS BUFFERING (IN MEMORY)

2.1) I create a memory representation of the contents of the directory'S files in the form of Map: scala.collection.immutable.Map[String,Array[String]]

2.2) I create an aggregation of strings with count of their occurrences: scala.collection.immutable.Map[String,scala.collection.immutable.Map[String,Int]] ---> A kind of Word Count in Scala (No Spark...)

Example:

val dir = "/home/a.brizi/VODAFONE/Shell/TEST"
val listOfFiles = getListOfFiles(dir)
val input = listOfFiles.map(file => (file.getName,Source.fromFile(file).getLines.mkString("\n").split("[\n& ]"))).toMap
val countedInput = input.map(pair => (pair._1, pair._2.map(word => (word,1)).groupBy(_._1).mapValues(seq => seq.map(_._2).reduce(_+_)).toMap))

countedInput: scala.collection.immutable.Map[String,scala.collection.immutable.Map[String,Int]] = 
Map(adevinta_1 -> Map(19125 -> 1, 16:27:07 -> 1, 20:34:25 -> 1, 5451 -> 1, 31211 -> 1, 03:26:04 -> 1, 15:04:14 -> 1, 06-11-1764 -> 1, 22:33:41 -> 1, 25285 -> 1, ADEVINTA_23436 -> 1, testdata_7_6378 -> 1, 9936 -> 1, ADEVINTA_12699 -> 2, ...), ... )
where:
adevinta_1  is the file name
ADEVINTA_12699 -> 2  is the count of occurrences of word "ADEVINTA_12699"

----------------------------------------------------------------------------------------------------------------------------

3) METHOD FOR SEARCHING "word" WITHIN THE CONTENT OF FILES:

3.1 inputData <---- countedInput (file content with aggregation and count)

3.2 funct <---- toBeSearched (list of words to search ...)

def myContains(inputData: Map[String,Map[String,Int]], funct: Seq[String]):Iterable[(String,Int)] = {
    
    inputData.map(pair => (pair._1, pair._2.keys.toList.map(word => (funct collect {case str if word equals str => 1}).fold(0)(_+_)).reduce(_+_)))

}

----------------------------------------------------------------------------------------------------------------------------

4) MAIN METHOD:

   def Search(dir: String): Unit = {
      val listOfFiles = getListOfFiles(dir)
      if (listOfFiles.length != 0) println(listOfFiles.length + " files read in directory " + dir) 
         else { println("wrong directory name: directory is empty...") ; System.exit(1) }
      val input = listOfFiles.map(file => (file.getName,Source.fromFile(file).getLines.mkString("\n").split("[\n& ]"))).toMap
      val countedInput = input.map(pair => (pair._1, pair._2.map(word => (word,1)).groupBy(_._1).mapValues(seq => seq.map(_._2).reduce(_+_)).toMap))
      var toBeSearched = scala.io.StdIn.readLine("search> ").split(" ")
      while (toBeSearched.size != 1 || toBeSearched(0) != ":quit") {
         val toBeSearchedLength = toBeSearched.size
         val output = myContains(countedInput,toBeSearched).filterNot(_._2 == 0)
         if (output.size == 0) print("no matches found\n") else {output.foreach(pair => println(pair._1 + " : " + (pair._2.toFloat/toBeSearchedLength)*100 + " %"))}
         toBeSearched = scala.io.StdIn.readLine("search> ").split(" ")
      }
      println("Now exit Searcher ...")
   }

----------------------------------------------------------------------------------------------------------------------------