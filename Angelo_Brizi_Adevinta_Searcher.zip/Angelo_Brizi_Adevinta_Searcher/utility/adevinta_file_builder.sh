#!/bin/bash

irow=$1
batch_dim=$2
fileName="testdata"

if [ $irow -le ${batch_dim} ]
then
    batch_dim=$irow
    batch_dim_last=0
    PARALLEL=1
else
    if [ $(($irow % ${batch_dim})) -ne 0 ]
    then
        batch_dim_last=$(($irow % ${batch_dim}))
    else
        batch_dim_last=0
    fi
fi
PARALLEL=$(($irow/${batch_dim}))

lower=1
upper=${batch_dim}

if [ ${PARALLEL} -gt 1 ] && [ ${batch_dim_last} -ne 0  ]
then
    PARALLEL=$((${PARALLEL} - 1))
fi

echo "--------------------------------------"
echo "batch_dim: $batch_dim"
echo "batch_dim_last: $batch_dim_last"
echo "PARALLEL: $PARALLEL"
echo "--------------------------------------"

for ((i=1;i<=$PARALLEL;i++))
do
  if [ $i -eq 1 ]
  then
      line="prjname|filename|ing_date|tablename|src_cnt"
      echo "$line" >> ${fileName}_1
  fi
  {
  for ((rowCnt=$lower;rowCnt<=$upper;rowCnt++))
  do
    line="ADEVINTA_$(($RANDOM % 10000000)) ${fileName}_${i}_${rowCnt} $(date -d "$((RANDOM% 2020))-$((RANDOM%12+1))-$((RANDOM%28+1)) $((RANDOM%23+1)):$((RANDOM%59+1)):$((RANDOM%59+1))" '+%d-%m-%Y %H:%M:%S') $(($RANDOM % 10000000))"
    echo "$line" >> ${fileName}_$i
  done
  } &
  lower=$(($upper + 1))
  upper=$(($upper + $batch_dim))
  echo "lanciato processo: [ $i / ${PARALLEL} ]"
done
wait

if [ ${batch_dim_last} -ne 0 ]
then
    for ((rowCnt=${lower};rowCnt<=$((${lower}+${batch_dim_last}-1));rowCnt++))
    do
      line="ADEVINTA_$(($RANDOM % 10000000)) ${fileName}_${i}_${rowCnt} $(date -d "$((RANDOM% 2020))-$((RANDOM%12+1))-$((RANDOM%28+1)) $((RANDOM%23+1)):$((RANDOM%59+1)):$((RANDOM%59+1))" '+%d-%m-%Y %H:%M:%S') $(($RANDOM % 10000000))"
      echo "$line" >> ${fileName}_$((${PARALLEL} + 1))
    done
fi

cmdAppend="cat ${fileName}_1"

for ((i=2;i<=${PARALLEL};i++))
do
  cmdAppend="${cmdAppend} ${fileName}_$i"
done

cmdAppend="$cmdAppend >> ${fileName}"

echo "--------------------------------------"
echo "cmdAppend: $cmdAppend"
echo "--------------------------------------"

$(eval ${cmdAppend})

rm -rf ${fileName}_*
